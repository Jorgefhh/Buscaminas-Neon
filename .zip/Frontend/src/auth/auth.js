// ============================================
// auth.js
// Acá manejamos lo que pasa cuando el usuario
// aprieta "Ingresar" o "Registrarse".
// Este archivo usa las funciones de api.js
// (por eso en el HTML, api.js se carga ANTES que este)
// ============================================

// ---------- Reloj de la franja decorativa ----------
// Esto es solo estético, no tiene nada que ver con el login.
const cajaReloj = document.getElementById("reloj");

function actualizarReloj() {
  if (!cajaReloj) return;
  const ahora = new Date();
  const horas = String(ahora.getHours()).padStart(2, "0");
  const minutos = String(ahora.getMinutes()).padStart(2, "0");
  cajaReloj.textContent = `${horas}:${minutos}`;
}

actualizarReloj();
setInterval(actualizarReloj, 1000 * 30); // se actualiza cada 30 segundos, no hace falta más

// ---------- LOGIN ----------
const formLogin = document.getElementById("form-login");

if (formLogin) {
  formLogin.addEventListener("submit", async (evento) => {
    evento.preventDefault(); // evita que la página se recargue sola

    const correo = document.getElementById("correo").value;
    const contrasena = document.getElementById("contrasena").value;
    const mensajeError = document.getElementById("mensaje-error");
    const boton = formLogin.querySelector("button");

    mensajeError.textContent = "";
    boton.disabled = true;
    boton.textContent = "Ingresando...";

    try {
      const respuesta = await loginUsuario({ correo, contrasena });

      // Guardamos el token para usarlo en los próximos pedidos al backend.
      // localStorage se borra solo si el usuario limpia el navegador o cierra sesión a mano.
      localStorage.setItem("token", respuesta.token);

      // Lo mandamos a su panel/dashboard
      window.location.href = "../juego/panel_tablero.html";
    } catch (error) {
      mensajeError.textContent = error.message;
      boton.disabled = false;
      boton.textContent = "Ingresar";
    }
  });
}

// ---------- REGISTRO ----------
const formRegistro = document.getElementById("form-registro");

if (formRegistro) {
  formRegistro.addEventListener("submit", async (evento) => {
    evento.preventDefault();

    const nombre = document.getElementById("nombre").value;
    const correo = document.getElementById("correo").value;
    const contrasena = document.getElementById("contrasena").value;
    const mensajeError = document.getElementById("mensaje-error");
    const mensajeExito = document.getElementById("mensaje-exito");
    const boton = formRegistro.querySelector("button");

    mensajeError.textContent = "";
    mensajeExito.textContent = "";
    boton.disabled = true;
    boton.textContent = "Creando cuenta...";

    try {
      await registrarUsuario({ nombre, correo, contrasena });

      mensajeExito.textContent = "¡Cuenta creada! Te llevamos al login...";

      // Esperamos un toque para que el usuario alcance a leer el mensaje
      setTimeout(() => {
        window.location.href = "login.html";
      }, 1200);
    } catch (error) {
      mensajeError.textContent = error.message;
      boton.disabled = false;
      boton.textContent = "Registrarse";
    }
  });
}
